# Safa — Android (Google Play)

Trusted Web Activity wrapper for https://slategray-opossum-294322.hostingersite.com (package `com.theonenetwork.safa`).
Built by GitHub Actions (unsigned). Signing happens privately, outside GitHub.
